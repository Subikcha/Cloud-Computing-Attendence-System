main file index.html
with requirements of mysql and apache server installed.
