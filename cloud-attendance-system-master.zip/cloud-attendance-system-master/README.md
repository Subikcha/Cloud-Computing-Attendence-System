# cloud-attendance-system
php,mysql,html,aws based cloud attendance system
